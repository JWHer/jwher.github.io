.------------------------------------------------------------.
|                 http://www.emulland.net/                   |
>------------------------------------------------------------<
|     You may have this game ROM ONLY if you are legally     |
|        entitled so. By "legally entitled" we mean:         |
|                                                            |
|     You own the actual arcade or gamepak of a ROM you      |
|      are downloading. Under the copyright laws of the      |
|       U.S., you are entitled to own a backup of any        |
|      software you have paid for. Since ROMS can't be       |
|       duplicated (not without special hardware), ROM       |
|      images are provided to the public as a service.       |
|                                                            |
|    Remember, the purpose of an emulator is to preserve     |
|     games (so that they don't dissappear), to have all     |
|    your games on your PC (so that you don't tie up the     |
|    family TV) and to keep a backup of games you own in     |
|      case the game (or arcade/home console) fails or       |
|                    have already failed.                    |
|                                                            |
|   It's for educational purposes only (in case you are an   |
|                   emulator programmer).                    |
|                                                            |
|    You will NEVER sell these ROMS for profit. Most game    |
|   companies don't mind the distribution of their game's    |
|      ROMS because they no longer exist, but they WILL      |
|                mind if someone sells them.                 |
|                                                            |
|    You will NOT distribute ROMS together with emulators    |
|            as a package. And again, NO selling.            |
|                                                            |
|   You will NEVER hold emulland.net (including its parent   |
|      company, webmasters, employees, staff or anybody      |
|       else related to this website) or our webhosts        |
|     responsible for any damage caused to your system,      |
|      for any legal actions taken against you for not       |
|  obeying the above stated rules, or for any other reason.  |
|                                                            |
|   emulland.net has not dumped the ROMS on this website,    |
|       and our purpose is to provide a service to the       |
|      Internet and gaming community. No harm is being       |
|        done to game companies, as the ROMS on this         |
|     website are of games that are no longer for sale,      |
|      from which game companies can no longer profit.       |
`------------------------------------------------------------�
